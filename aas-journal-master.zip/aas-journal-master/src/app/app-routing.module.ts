import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { AuthGuard } from './core/auth.guard';
import { UserLoginComponent } from './ui/user-login/user-login.component';
import { HomePageComponent } from './ui/home-page/home-page.component';
import {AdminPageComponent} from './ui/admin-page/admin-page.component';
import {ArticleComponent} from './ui/article/article.component';
import {PublicationEthicsComponent} from './ui/publication-ethics/publication-ethics.component';
import {PublicationRuComponent} from './ui/publication-ru/publication-ru.component';



const routes: Routes = [
  { path: '', component: HomePageComponent },
  { path: 'login', component: UserLoginComponent },
  { path: 'admin', component: AdminPageComponent },
  { path: 'publication-en', component: PublicationEthicsComponent },
  { path: 'publication-ru', component: PublicationRuComponent },
  { path: 'admin', component: AdminPageComponent },
  { path: 'article/:id', component: ArticleComponent },

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }

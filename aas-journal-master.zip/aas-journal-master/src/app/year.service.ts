import { Injectable } from '@angular/core';
import { AngularFirestore, AngularFirestoreCollection, AngularFirestoreDocument } from '@angular/fire/firestore';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';


@Injectable({
  providedIn: 'root'
})
export class YearService {

  yearsCollection: AngularFirestoreCollection<any>;
  yearDocument:   AngularFirestoreDocument<any>;

  constructor(private afs: AngularFirestore) {
    this.yearsCollection = this.afs.collection('journals');
  }

  getData(): Observable<any[]> {
    // ['added', 'modified', 'removed']
    return this.yearsCollection.snapshotChanges().pipe(
      map((actions) => {
        return actions.map((a) => {
          const data = a.payload.doc.data();
          return { id: a.payload.doc.id, ...data };
        });
      })
    );
  }

  getYear(id: string) {
    return this.afs.doc<any>(`journals/${id}`);
  }

  createYear(note: any) {
    return this.yearsCollection.add(note);
  }

  updateYear(id: string, data: any) {
    return this.getYear(id).update(data);
  }

  deleteYear(id: string) {
    return this.getYear(id).delete();
  }
}

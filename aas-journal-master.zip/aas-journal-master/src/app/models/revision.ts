export class Revision {
  displayName: string;
  link: string;
  journalId: string;
}

export class Journal {
  displayName: string;
}

export class Subject {
  displayName: string;
  revisionId: string;
  journalName: string;
  revisionName: string;
}

export class Article {
  subjectId: string;
  author: string;
  titleEn: string;
  titleRu: string;
  titleKg: string;
  titleTr: string;
  descriptionEn: string;
  descriptionRu: string;
  descriptionKg: string;
  descriptionTr: string;
  linkEn: string;
  linkRu: string;
  linkKg: string;
  linkTr: string;
  id: any;
}

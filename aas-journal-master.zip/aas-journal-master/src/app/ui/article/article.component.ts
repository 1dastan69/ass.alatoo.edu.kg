import {Component, OnInit} from '@angular/core';
import {ActivatedRoute} from '@angular/router';
import {ArticleService} from '../../article.service';
import {SubjectService} from '../../subject.service';
import {Subject} from '../../models/subject';

@Component({
  selector: 'article',
  templateUrl: './article.component.html',
  styleUrls: ['./article.component.scss']
})
export class ArticleComponent implements OnInit {

  selectedId: string;
  currentSubject = new Subject();
  listOfArticles: any = new Array<object>();

  constructor(private route: ActivatedRoute,
              private subjectService: SubjectService,
              private articleService: ArticleService) {

    this.selectedId = this.route.snapshot.paramMap.get('id');

    this.subjectService.getData().subscribe((data) => {
      const currentSubject = data.filter(sub => sub.id === this.selectedId);
      this.currentSubject = currentSubject[0];
    }, error => {
      console.log(error);
    });

    this.articleService.getData().subscribe((data) => {
      const allArticles = data.sort((a, b) => (a.author > b.author) ? 1 : -1);
      this.listOfArticles = allArticles.filter(article => article.subjectId === this.selectedId);
    }, error => {
      console.log(error);
    });
  }


  ngOnInit() {
  }

}

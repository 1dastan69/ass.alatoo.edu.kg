import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'publication-ethics',
  templateUrl: './publication-ethics.component.html',
  styleUrls: ['./publication-ethics.component.scss']
})
export class PublicationEthicsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

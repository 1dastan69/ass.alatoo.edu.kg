import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'publication-ru',
  templateUrl: './publication-ru.component.html',
  styleUrls: ['./publication-ru.component.scss']
})
export class PublicationRuComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

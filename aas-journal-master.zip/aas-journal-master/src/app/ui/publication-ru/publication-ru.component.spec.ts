import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PublicationRuComponent } from './publication-ru.component';

describe('PublicationRuComponent', () => {
  let component: PublicationRuComponent;
  let fixture: ComponentFixture<PublicationRuComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PublicationRuComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PublicationRuComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

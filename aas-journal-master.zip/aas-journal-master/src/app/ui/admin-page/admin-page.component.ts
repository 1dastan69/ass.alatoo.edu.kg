import {Component, OnInit} from '@angular/core';
import {SubjectService} from '../../subject.service';
import {ArticleService} from '../../article.service';
import {YearService} from '../../year.service';
import {NotifyService} from '../../core/notify.service';
import {PublishService} from '../../publish.service';
import {FormBuilder, Validators} from '@angular/forms';
import {AuthService} from '../../core/auth.service';
import {Journal} from '../../models/journal';
import {Subject} from '../../models/subject';
import {Article} from '../../models/article';
import {Revision} from '../../models/revision';

@Component({
  selector: 'admin-page',
  templateUrl: './admin-page.component.html',
  styleUrls: ['./admin-page.component.scss']
})
export class AdminPageComponent implements OnInit {
  isYearModalActive: boolean = false;
  isRevisionModalActive: boolean = false;
  isSubjectModalActive: boolean = false;
  isArticleModalActive: boolean = false;
  deleteYearModalActive: boolean = false;
  deleteRevisionModalActive: boolean = false;
  deleteSubjectModalActive: boolean = false;
  deleteArticleModalActive: boolean = false;

  yearForm = this.fb.group({
    year: ['', Validators.required],
    selectedYear: [''],
  });

  publishForm = this.fb.group({
    year: ['', Validators.required],
    publish: [''],
    selectedPublish: [''],
  });

  subjectForm = this.fb.group({
    year: ['', Validators.required],
    publish: [''],
    subject: [''],
    selectedSubject: [''],
  });

  articleForm = this.fb.group({
    year: ['', Validators.required],
    publish: [''],
    subject: [''],
    selectedArticle: [''],
    author: [''],
    linkRu: [''],
    linkEn: [''],
    linkKg: [''],
    linkTr: [''],
    titleRu: [''],
    titleEn: [''],
    titleKg: [''],
    titleTr: [''],
    descriptionRu: [''],
    descriptionEn: [''],
    descriptionKg: [''],
    descriptionTr: [''],
  });

  listOfYears: any = new Array<object>();
  listOfRevisions: any = new Array<object>();
  listOfSubjects: any = new Array<object>();
  listOfArticles: any = new Array<object>();
  currentListOfRevisions: any = new Array<object>();
  currentListOfSubjects: any = new Array<object>();
  currentListOfArticles: any = new Array<object>();

  journal: Journal = new Journal();
  revision: Revision = new Revision();
  subject: Subject = new Subject();
  article: Article = new Article();

  selectedJournal: any;
  selectedRevision: any;
  selectedSubject: any;
  selectedArticle: any;
  currentText = String;

  constructor(public auth: AuthService,
              private fb: FormBuilder,
              private yearService: YearService,
              private publishService: PublishService,
              private subjectService: SubjectService,
              private articleService: ArticleService,
              private notify: NotifyService) {
  }

  ngOnInit() {
    this.yearService.getData().subscribe((data) => {
      this.listOfYears = data.sort((a, b) => (a.displayName < b.displayName) ? 1 : -1);
    }, error => {
      console.log(error);
    });

    this.publishService.getData().subscribe((data) => {
      this.listOfRevisions = data.sort((a, b) => (a.displayName > b.displayName) ? 1 : -1);
    }, error => {
      console.log(error);
    });

    this.subjectService.getData().subscribe((data) => {
      this.listOfSubjects = data.sort((a, b) => (a.displayName > b.displayName) ? 1 : -1);
    }, error => {
      console.log(error);
    });

    this.articleService.getData().subscribe((data) => {
      this.listOfArticles = data.sort((a, b) => (a.displayName > b.displayName) ? 1 : -1);
    }, error => {
      console.log(error);
    });
  }

  closeModal() {
    this.isYearModalActive = false;
    this.isRevisionModalActive = false;
    this.isSubjectModalActive = false;
    this.isArticleModalActive = false;
    this.deleteYearModalActive = false;
    this.deleteRevisionModalActive = false;
    this.deleteSubjectModalActive = false;
    this.deleteArticleModalActive = false;

    this.selectedJournal = '';
    this.selectedRevision = '';
    this.selectedSubject = '';
    this.selectedArticle = '';
    this.article = new Article();
  }

  showYearManagement() {
    this.isYearModalActive = !this.isYearModalActive;
  }

  showRevisionManagement() {
    this.isRevisionModalActive = !this.isRevisionModalActive;
  }

  showSubjectManagement() {
    this.isSubjectModalActive = !this.isSubjectModalActive;
  }

  showArticleManagement() {
    this.isArticleModalActive = !this.isArticleModalActive;
  }

  logout() {
    this.auth.signOut();
  }

  journalChanged(obj) {
    const filteredList = this.listOfRevisions.filter(elm => elm.journalId === obj.id);

    this.currentListOfRevisions = filteredList;
  }

  revisionChanged(obj) {
    const filteredList = this.listOfSubjects.filter(elm => elm.revisionId === obj.id);

    this.currentListOfSubjects = filteredList;
  }

  subjectChanged(obj) {
    const filteredList = this.listOfArticles.filter(elm => elm.subjectId === obj.id);

    this.currentListOfArticles = filteredList;
  }

  articleChanged(obj) {
    this.article = obj;
  }

  showDeleteYearModal() {
    this.currentText = this.selectedJournal.displayName;
    this.deleteYearModalActive = true;
  }

  showDeleteRevisionModal() {
    this.currentText = this.selectedRevision.displayName;
    this.deleteRevisionModalActive = true;
  }

  showDeleteSubjectModal() {
    this.currentText = this.selectedSubject.displayName;
    this.deleteSubjectModalActive = true;
  }

  showDeleteArticleModal() {
    this.currentText = this.selectedArticle.author;
    this.deleteArticleModalActive = true;
  }

  onAddYear() {
    const journal = {
      displayName: this.journal.displayName
    };

    this.yearService.createYear(journal).then((data) => {
      console.log('year was created:', data);
      this.closeModal();
      this.notify.update(journal + ' saved successfully', 'success');
    });
  }

  onUpdateYear() {
    console.log('update journal clicked');
    const selectedJournal = this.selectedJournal;
    const newJournal = {
      displayName: this.journal.displayName
    };

    this.yearService.updateYear(selectedJournal.id, newJournal).then((data) => {
      console.log('journal was updated:', data);
      this.closeModal();
      this.notify.update(selectedJournal.displayName + ' updated successfully', 'success');
    });
  }

  onDeleteYear() {
    const selectedJournal = this.selectedJournal;

    this.yearService.deleteYear(selectedJournal.id).then((data) => {
      console.log('journal was deleted:', data);
      this.closeModal();
      this.notify.update(selectedJournal.displayName + ' deleted successfully', 'success');
    });
  }


  onAddRevision() {
    const revision = {
      displayName: this.revision.displayName,
      link: this.revision.link,
      journalId: this.selectedJournal.id
    };

    this.publishService.createPublish(revision).then((data) => {
      console.log('revision was created:', data);
      this.closeModal();
      this.notify.update(revision.displayName + ' saved successfully', 'success');
    });
  }

  onUpdateRevision() {
    const selectedRevision = this.selectedRevision;

    selectedRevision.journalId = this.selectedJournal.id;
    selectedRevision.link = this.revision.link;
    selectedRevision.displayName = this.revision.displayName;

    this.publishService.updatePublish(selectedRevision.id, JSON.parse(JSON.stringify(selectedRevision))).then((data) => {
      console.log('revision was updated');
      this.closeModal();
      this.notify.update(selectedRevision.displayName + ' updated successfully', 'success');
    });
  }

  onDeleteRevision() {
    const selectedRevision = this.selectedRevision;

    this.publishService.deletePublish(selectedRevision.id).then((data) => {
      console.log('revision was deleted');
      this.closeModal();
      this.notify.update(selectedRevision.displayName + ' deleted successfully', 'success');
    });
  }


  onAddSubject() {
    const subject = {
      displayName: this.subject.displayName,
      revisionId: this.selectedRevision.id,
      journalName: this.selectedJournal.displayName,
      revisionName: this.selectedRevision.displayName
    };

    this.subjectService.createSubject(subject).then((data) => {
      console.log('subject was created:', data);
      this.closeModal();
      this.notify.update(subject.displayName + ' saved successfully', 'success');
    });
  }

  onUpdateSubject() {
    const selectedSubject = this.selectedSubject;
    selectedSubject.revisionId = this.selectedRevision.id;
    selectedSubject.displayName = this.subject.displayName;

    this.subjectService.updateSubject(selectedSubject.id, JSON.parse(JSON.stringify(selectedSubject))).then((data) => {
      console.log('subject was updated');
      this.closeModal();
      this.notify.update(selectedSubject.displayName + ' updated successfully', 'success');
    });
  }

  onDeleteSubject() {
    this.subjectService.deleteSubject(this.selectedSubject.id).then((data) => {
      console.log('subject was deleted');
      this.closeModal();
      this.notify.update(this.selectedSubject.displayName + ' deleted successfully', 'success');
    });
  }

  onAddArticle() {
    const article = JSON.parse(JSON.stringify(this.article));
    article.subjectId = this.selectedSubject.id;

    this.articleService.createArticle(article).then((data) => {
      console.log('article was created:', data);
      this.closeModal();
      this.notify.update(article.author + ' saved successfully', 'success');
    });
  }

  onUpdateArticle() {
    const selectedArticle = this.article;
    selectedArticle.id = this.selectedArticle.id;
    selectedArticle.subjectId = this.selectedSubject.id;

    this.articleService.updateArticle(selectedArticle.id, JSON.parse(JSON.stringify(selectedArticle))).then((data) => {
      console.log('article was updated:', data);
      this.closeModal();
      this.notify.update(selectedArticle.author + ' updated successfully', 'success');
    });
  }

  onDeleteArticle() {
    this.articleService.deleteArticle(this.selectedArticle.id).then((data) => {
      console.log('article was deleted');
      this.closeModal();
      this.notify.update(this.selectedArticle.author + ' deleted successfully', 'success');
    });
  }


}

import {Component, OnInit} from '@angular/core';
import {FormBuilder} from '@angular/forms';
import {YearService} from '../../year.service';
import {PublishService} from '../../publish.service';
import {SubjectService} from '../../subject.service';
import {ArticleService} from '../../article.service';
import {NotifyService} from '../../core/notify.service';

@Component({
  selector: 'home-page',
  templateUrl: './home-page.component.html',
  styleUrls: ['./home-page.component.scss']
})
export class HomePageComponent implements OnInit {

  listOfJournals: any = new Array<object>();
  listOfRevisions: any = new Array<object>();
  listOfSubjects: any = new Array<object>();
  listOfArticles: any = new Array<object>();
  textSearch = '';
  websiteUrl = '';


  constructor(private fb: FormBuilder,
              private yearService: YearService,
              private publishService: PublishService,
              private subjectService: SubjectService,
              private articleService: ArticleService,
              private notify: NotifyService) {
  }

  ngOnInit() {
    this.websiteUrl = 'https://www.google.com/search?q=site:' + window.location.hostname + ' ';
    this.articleService.getData().subscribe((data) => {
      this.listOfArticles = data.sort((a, b) => (a.author < b.author) ? 1 : -1);
    }, error => {
      console.log(error);
    });

    this.subjectService.getData().subscribe((data) => {
      const listOfSubjects = data.sort((a, b) => (a.displayName < b.displayName) ? 1 : -1);
      const listOfArticles = this.listOfArticles;
      const newList = [];

      listOfSubjects.forEach((subject) => {
        const newSubject = subject;
        const articles = listOfArticles.filter(article => article.subjectId === subject.id);
        newSubject.articles = articles;

        newList.push(newSubject);
      });
      this.listOfSubjects = newList;
    }, error => {
      console.log(error);
    });

    this.publishService.getData().subscribe((data) => {
      const listOfRevisions = data.sort((a, b) => (a.displayName > b.displayName) ? 1 : -1);
      const listOfSubjects = this.listOfSubjects;
      const newList = [];

      listOfRevisions.forEach((revision) => {
        const newRevision = revision;
        const subjects = listOfSubjects.filter(subject => subject.revisionId === revision.id);
        newRevision.subjects = subjects;

        newList.push(newRevision);
      });

      this.listOfRevisions = newList;
    }, error => {
      console.log(error);
    });

    this.yearService.getData().subscribe((data) => {
      const listOfJournals = data.sort((a, b) => (a.displayName < b.displayName) ? 1 : -1);
      const listOfRevisions = this.listOfRevisions;
      const newList = [];

      listOfJournals.forEach((journal) => {
        const newJournal = journal;
        const revisions = listOfRevisions.filter(revision => revision.journalId === journal.id);
        newJournal.revisions = revisions;

        newList.push(newJournal);
      });

      this.listOfJournals = newList;
    }, error => {
      console.log(error);
    });
  }


}

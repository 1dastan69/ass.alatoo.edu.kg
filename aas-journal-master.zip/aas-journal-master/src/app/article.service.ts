import { Injectable } from '@angular/core';
import { AngularFirestore, AngularFirestoreCollection, AngularFirestoreDocument } from '@angular/fire/firestore';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class ArticleService {
  articlesCollection: AngularFirestoreCollection<any>;
  articleDocument:   AngularFirestoreDocument<any>;

  constructor(private afs: AngularFirestore) {
    this.articlesCollection = this.afs.collection('articles');
  }

  getData(): Observable<any[]> {
    // ['added', 'modified', 'removed']
    return this.articlesCollection.snapshotChanges().pipe(
      map((actions) => {
        return actions.map((a) => {
          const data = a.payload.doc.data();
          return { id: a.payload.doc.id, ...data };
        });
      })
    );
  }

  getArticle(id: string) {
    return this.afs.doc<any>(`articles/${id}`);
  }

  createArticle(note: any) {
    return this.articlesCollection.add(note);
  }

  updateArticle(id: string, data: any) {
    return this.getArticle(id).update(data);
  }

  deleteArticle(id: string) {
    return this.getArticle(id).delete();
  }
}

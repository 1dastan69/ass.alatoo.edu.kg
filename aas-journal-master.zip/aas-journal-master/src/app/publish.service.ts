import { Injectable } from '@angular/core';
import { AngularFirestore, AngularFirestoreCollection, AngularFirestoreDocument } from '@angular/fire/firestore';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';


@Injectable({
  providedIn: 'root'
})
export class PublishService {

  publishsCollection: AngularFirestoreCollection<any>;
  publishDocument:   AngularFirestoreDocument<any>;

  constructor(private afs: AngularFirestore) {
    this.publishsCollection = this.afs.collection('revisions');
  }

  getData(): Observable<any[]> {
    // ['added', 'modified', 'removed']
    return this.publishsCollection.snapshotChanges().pipe(
      map((actions) => {
        return actions.map((a) => {
          const data = a.payload.doc.data();
          return { id: a.payload.doc.id, ...data };
        });
      })
    );
  }

  getPublish(id: string) {
    return this.afs.doc<any>(`revisions/${id}`);
  }

  createPublish(content: any) {
    return this.publishsCollection.add(content);
  }

  updatePublish(id: string, data: any) {
    return this.getPublish(id).update(data);
  }

  deletePublish(id: string) {
    return this.getPublish(id).delete();
  }
}

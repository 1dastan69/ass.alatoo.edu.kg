import { Injectable } from '@angular/core';
import { AngularFirestore, AngularFirestoreCollection, AngularFirestoreDocument } from '@angular/fire/firestore';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class SubjectService {
  subjectsCollection: AngularFirestoreCollection<any>;
  subjectDocument:   AngularFirestoreDocument<any>;

  constructor(private afs: AngularFirestore) {
    this.subjectsCollection = this.afs.collection('subjects');
  }

  getData(): Observable<any[]> {
    // ['added', 'modified', 'removed']
    return this.subjectsCollection.snapshotChanges().pipe(
      map((actions) => {
        return actions.map((a) => {
          const data = a.payload.doc.data();
          return { id: a.payload.doc.id, ...data };
        });
      })
    );
  }

  getSubject(id: string) {
    return this.afs.doc<any>(`subjects/${id}`);
  }

  createSubject(note: any) {
    return this.subjectsCollection.add(note);
  }

  updateSubject(id: string, data: any) {
    return this.getSubject(id).update(data);
  }

  deleteSubject(id: string) {
    return this.getSubject(id).delete();
  }
}

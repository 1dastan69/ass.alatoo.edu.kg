export const environment = {
  production: true,
  firebase: {
    apiKey: 'AIzaSyDoUTikKdCuBGx2a9EL5Z4mR2o9ETSW26k',
    authDomain: 'aas-journal-468c1.firebaseapp.com',
    databaseURL: 'https://aas-journal-468c1.firebaseio.com',
    projectId: 'aas-journal-468c1',
    storageBucket: '',
    messagingSenderId: '245622050787',
    appId: '1:245622050787:web:780c1e6348e60b0e'
  }
};
